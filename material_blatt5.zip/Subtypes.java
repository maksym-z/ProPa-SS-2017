public class Subtypes {
  public static interface A {}
  public static interface B {}
  public static interface C {}
  public static interface D {}
  public static interface E {}
  public static interface F {}
  public static interface G {}
  public static interface H {}
  public static interface I {}
}