% S5
connection(tamm,ludwigsburg).
connection(ludwigsburg,zuffenhausen).
connection(zuffenhausen,hbf).

% S1
connection(plochingen,esslingen).
connection(esslingen,cannstatt).
connection(cannstatt,hbf).
connection(hbf,universitaet).
connection(universitaet,vaihingen).
connection(vaihingen,boeblingen).
connection(ehningen,boeblingen).
connection(herrenberg,boeblingen).

% S6
connection(renningen,leonberg).
connection(leonberg,ditzingen).
connection(ditzingen,korntal).
connection(korntal,zuffenhausen).
connection(zuffenhausen,hbf).

% S60
connection(hbf,zuffenhausen).
connection(zuffenhausen,korntal).
connection(korntal,ditzingen).
connection(ditzingen,leonberg).
connection(leonberg,renningen).
connection(renningen,sindelfingen).
connection(sindelfingen,boeblingen).

% Fuegen Sie hier unten Ihre eigenen Definitionen ein.
